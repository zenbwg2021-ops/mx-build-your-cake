// src/App.tsx
import { useState } from "react";
import "./App.css";
import { MXBrand, MXTheme } from "./theme";
import { newTierLike, type CakeDesign } from "./models";
import { CakePreview } from "./components/CakePreview";
import { TierEditor } from "./components/TierEditor";
import { DecorationPicker } from "./components/DecorationPicker";
import { MessageNotes } from "./components/MessageNotes";
import { PriceSummary } from "./components/PriceSummary";

export default function App() {
  const [design, setDesign] = useState<CakeDesign>({
    tiers: [newTierLike()],
    decorations: new Set(),
    message: "",
    allergyNotes: "",
  });
  const [showCheckout, setShowCheckout] = useState(false);

  return (
    <div className="page">
      <header className="hero">
        <div className="logo">{MXBrand.short}</div>
        <div className="heroText">
          <h1>{MXBrand.name}</h1>
          <p>Design your tailor‑made cake</p>
        </div>
      </header>

<main className="content">
  <section className="preview">
    <h3>Your cake preview</h3>
    <CakePreview design={design} />
  </section>

  <div className="sidebar">
    <TierEditor design={design} setDesign={setDesign} />
    <DecorationPicker design={design} setDesign={setDesign} />
    <MessageNotes design={design} setDesign={setDesign} />
    <PriceSummary design={design} />
    <button className="primary" onClick={() => setShowCheckout(true)}>
      Proceed to checkout
    </button>
  </div>
</main>


      {showCheckout && (
        <div className="modal">
          <div className="modalBody">
            <h3>Checkout</h3>
            <CakePreview design={design} />
            <div style={{ marginTop: 12 }}>
              <p><strong>Order summary</strong></p>
              {design.tiers.map(t => (
                <div key={t.id}>{t.size} • {t.flavor} • {t.frosting}</div>
              ))}
              {design.decorations.size > 0 && (
                <div>Decorations: {Array.from(design.decorations).join(", ")}</div>
              )}
              {design.message && <div>Message: “{design.message}”</div>}
              {design.allergyNotes && <div>Notes: {design.allergyNotes}</div>}
            </div>
            <div className="actions">
              <button className="primary" onClick={() => {/* integrate payment later */}}>
                Place order
              </button>
              <button className="link" onClick={() => setShowCheckout(false)}>Close</button>
            </div>
          </div>
        </div>
      )}

      <footer className="footer">
        © {new Date().getFullYear()} {MXBrand.name}. All rights reserved.
      </footer>

      <style>{`
        .hero { background: ${MXTheme.gradient}; color: #fff; padding: 20px; border-bottom-left-radius: 24px; border-bottom-right-radius: 24px; box-shadow: 0 8px 20px rgba(255,143,0,0.25); display:flex; align-items:center; gap:12px; }
        .logo { width: 36px; height: 36px; border-radius: 50%; background: ${MXTheme.orange}; display:flex; align-items:center; justify-content:center; font-weight:700; }
        .content { padding: 16px; display: grid; gap: 16px; max-width: 900px; margin: 0 auto; }
        .card { padding:16px; background: rgba(255,255,255,0.6); backdrop-filter: saturate(180%) blur(8px); border-radius: 16px; border: 1px solid rgba(255,209,51,0.6); }
        .primary { padding: 12px 16px; border:none; border-radius:12px; color:#fff; background-image:${MXTheme.gradient}; font-weight:600; cursor:pointer; }
        .modal { position: fixed; inset: 0; background: rgba(0,0,0,0.25); display:flex; align-items:center; justify-content:center; }
        .modalBody { background:#fff; padding:16px; border-radius:16px; width: min(640px, 90%); }
        .actions { display:flex; gap:8px; margin-top: 12px; }
        .link { border:none; background:transparent; color:${MXTheme.orange}; cursor:pointer; }
        .footer { text-align:center; color: ${MXTheme.text}; padding: 20px; }
      `}</style>
    </div>
  );
}