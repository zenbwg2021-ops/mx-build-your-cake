import React from "react";
import { type CakeDesign, Decorations, type Decoration, labelDecoration } from "../models";
import { cardStyle, MXTheme } from "../theme";

export const DecorationPicker: React.FC<{
  design: CakeDesign;
  setDesign: (d: CakeDesign) => void;
}> = ({ design, setDesign }) => {
  function toggle(d: Decoration) {
    const next = new Set(design.decorations);
    next.has(d) ? next.delete(d) : next.add(d);
    setDesign({ ...design, decorations: next });
  }

  return (
    <div style={cardStyle}>
      <h3 style={{ margin: 0, color: MXTheme.text }}>Decorations</h3>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px,1fr))', gap: 8 }}>
        {Decorations.map(d => {
          const isOn = design.decorations.has(d);
          return (
            <button key={d} onClick={() => toggle(d)} style={{
              display:'flex', alignItems:'center', gap:8, justifyContent:'space-between',
              padding: 10, borderRadius: 12, cursor:'pointer', border: '1px solid #ddd',
              background: isOn ? 'rgba(255,209,51,0.25)' : MXTheme.cream
            }}>
              <span style={{ display:'flex', alignItems:'center', gap:8 }}>
                <span style={{
                  width: 20, height: 20, borderRadius: 999,
                  background: isOn ? MXTheme.orange : '#ccc'
                }} />
                <span style={{ color: MXTheme.text }}>{labelDecoration(d)}</span>
              </span>
              <span style={{
                fontSize: 12, padding: '4px 8px', borderRadius: 999,
                background: 'rgba(255,143,0,0.15)'
              }}>
                {priceLabel(d)}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

function priceLabel(d: Decoration) {
  switch (d) {
    case 'sprinkles': return 'HKD 18';
    case 'fruit': return 'HKD 48';
    case 'macaron': return 'HKD'
  }
}