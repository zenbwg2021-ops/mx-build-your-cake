import React from "react";
import type { CakeDesign } from "../models";
import { MXTheme } from "../theme";

function frostingColor(f: string) {
  switch (f) {
    case "buttercream": return MXTheme.cream;
    case "freshCream": return "#FFFFFF";
    case "creamCheese": return "#FAF0E9";
    case "ganache": return "#522B1F";
    default: return MXTheme.cream;
  }
}

export const CakePreview: React.FC<{ design: CakeDesign }> = ({ design }) => {
  return (
    <div style={{
      borderRadius: 24,
      background: MXTheme.cream,
      border: `2px solid rgba(255,209,51,0.4)`,
      padding: 16,
      boxShadow: `0 8px 20px rgba(255,143,0,0.15)`,
      height: 280,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'center' }}>
        {design.tiers.map((tier, idx) => {
          const widthScale = 1 - idx * 0.12;
          return (
            <div key={tier.id} style={{
              width: 240 * widthScale,
              height: 40,
              borderRadius: 16,
              background: frostingColor(tier.frosting),
              border: `2px solid rgba(255,143,0,0.4)`,
              display: 'flex',
              alignItems: 'center',
              padding: '0 8px',
              color: MXTheme.text,
              gap: 8
            }}>
              <div style={{ width: 10, height: 10, borderRadius: '50%', background: 'rgba(255,143,0,0.25)' }} />
              <small>{tier.size} • {tier.flavor[0].toUpperCase() + tier.flavor.slice(1)}</small>
            </div>
          );
        })}
        {design.decorations.size > 0 && (
          <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
            {Array.from(design.decorations).map(d => (
              <span key={d} style={{
                fontSize: 12, padding: '4px 8px', borderRadius: 999,
                background: 'rgba(255,143,0,0.15)', color: MXTheme.text
              }}>{d === 'customTopper' ? 'Custom Topper' : d.charAt(0).toUpperCase()+d.slice(1)}</span>
            ))}
          </div>
        )}
        {design.message && (
          <div style={{ marginTop: 4, color: MXTheme.text, fontWeight: 600 }}>“{design.message}”</div>
        )}
      </div>
    </div>
  );
};