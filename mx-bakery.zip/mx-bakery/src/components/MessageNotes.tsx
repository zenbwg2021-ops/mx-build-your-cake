import React from "react";
import { type CakeDesign } from "../models";
import { cardStyle, MXTheme } from "../theme";

export const MessageNotes: React.FC<{
  design: CakeDesign;
  setDesign: (d: CakeDesign) => void;
}> = ({ design, setDesign }) => {
  return (
    <div style={cardStyle}>
      <h3 style={{ margin: 0, color: MXTheme.text }}>Message & notes</h3>
      <div style={{ display:'grid', gap:8 }}>
        <input
          placeholder="Cake message (optional)"
          value={design.message}
          onChange={e => setDesign({ ...design, message: e.target.value })}
          style={{ padding: 10, borderRadius: 8, border: '1px solid #ddd' }}
        />
        <input
          placeholder="Allergy or dietary notes (optional)"
          value={design.allergyNotes}
          onChange={e => setDesign({ ...design, allergyNotes: e.target.value })}
          style={{ padding: 10, borderRadius: 8, border: '1px solid #ddd' }}
        />
      </div>
    </div>
  );
};