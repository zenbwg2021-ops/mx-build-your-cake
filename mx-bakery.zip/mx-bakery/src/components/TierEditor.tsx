import React from "react";
import { type CakeDesign, CakeSizes, CakeFlavors, Frostings, type CakeTier, newTierLike } from "../models";
import { cardStyle, MXTheme } from "../theme";

export const TierEditor: React.FC<{
  design: CakeDesign;
  setDesign: (d: CakeDesign) => void;
}> = ({ design, setDesign }) => {

  function updateTier(updated: CakeTier) {
    setDesign({
      ...design,
      tiers: design.tiers.map(t => t.id === updated.id ? updated : t)
    });
  }

  function removeTier(id: string) {
    setDesign({ ...design, tiers: design.tiers.filter(t => t.id !== id) });
  }

  function addTier() {
    const next = newTierLike(design.tiers.at(-1));
    setDesign({ ...design, tiers: [...design.tiers, next] });
  }

  return (
    <div style={cardStyle}>
      <h3 style={{ margin: 0, color: MXTheme.text }}>Tiers</h3>
      <div style={{ display: 'grid', gap: 12 }}>
        {design.tiers.map(tier => (
          <div key={tier.id} style={{
            padding: 8, background: MXTheme.cream, borderRadius: 12,
            border: `1px solid rgba(255,143,0,0.25)`
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems:'center' }}>
              <strong>Tier</strong>
              <button onClick={() => removeTier(tier.id)} style={{
                border: 'none', background: 'transparent', color: '#B00020', cursor: 'pointer'
              }}>Delete</button>
            </div>

            <label>
              Size
              <div style={{ display:'flex', gap:8, marginTop:4 }}>
                {CakeSizes.map(s => (
                  <button key={s}
                    onClick={() => updateTier({ ...tier, size: s })}
                    style={{
                      padding: '6px 10px',
                      borderRadius: 8,
                      border: '1px solid #ddd',
                      background: tier.size === s ? 'rgba(255,209,51,0.3)' : '#fff',
                      cursor: 'pointer'
                    }}>{s}</button>
                ))}
              </div>
            </label>

            <label style={{ display:'block', marginTop:8 }}>
              Flavor
              <select value={tier.flavor}
                onChange={e => updateTier({ ...tier, flavor: e.target.value as any })}
                style={{ width: '100%', padding: 8, borderRadius: 8, border: '1px solid #ddd' }}>
                {CakeFlavors.map(f => <option key={f} value={f}>{f[0].toUpperCase()+f.slice(1)}</option>)}
              </select>
            </label>

            <label style={{ display:'block', marginTop:8 }}>
              Frosting
              <select value={tier.frosting}
                onChange={e => updateTier({ ...tier, frosting: e.target.value as any })}
                style={{ width: '100%', padding: 8, borderRadius: 8, border: '1px solid #ddd' }}>
                {Frostings.map(fr => <option key={fr} value={fr}>{fr[0].toUpperCase()+fr.slice(1)}</option>)}
              </select>
            </label>
          </div>
        ))}
        <button onClick={addTier} style={{
          padding: '10px 12px',
          borderRadius: 12,
          border: 'none',
          color: '#fff',
          backgroundImage: MXTheme.gradient,
          cursor: 'pointer'
        }}>Add tier</button>
      </div>
    </div>
  );
};