import React from "react";
import { type CakeDesign, estimatedServings, priceHKD } from "../models";
import { cardStyle, MXTheme } from "../theme";

export const PriceSummary: React.FC<{ design: CakeDesign }> = ({ design }) => {
  return (
    <div style={cardStyle}>
      <div style={{ display:'flex', alignItems:'center' }}>
        <div style={{ flex: 1 }}>
          <div style={{ color: MXTheme.text }}>
            Estimated servings: {estimatedServings(design)}
          </div>
          <div style={{ fontWeight: 600, color: MXTheme.text, marginTop: 4 }}>
            Subtotal
          </div>
        </div>
        <div style={{ fontWeight: 700, color: MXTheme.orange, fontSize: 18 }}>
          HKD {priceHKD(design)}
        </div>
      </div>
    </div>
  );
};