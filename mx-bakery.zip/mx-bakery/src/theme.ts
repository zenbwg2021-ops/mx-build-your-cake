export const MXBrand = {
  name: "Maxim's Bakery",
  short: "MX",
};

export const MXTheme = {
  orange: "#FF8F00",
  yellow: "#FFD133",
  cream: "#FFF7EC",
  text: "rgba(0,0,0,0.8)",
  gradient: `linear-gradient(135deg, #FF8F00 0%, #FFD133 100%)`,
};

export const cardStyle: React.CSSProperties = {
  padding: 16,
  background: "rgba(255,255,255,0.6)",
  backdropFilter: "saturate(180%) blur(8px)",
  borderRadius: 16,
  border: `1px solid rgba(255, 209, 51, 0.6)`,
};