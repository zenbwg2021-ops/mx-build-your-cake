export type CakeSize = '6"' | '8"' | '10"' | '12"';
export const CakeSizes: CakeSize[] = ['6"', '8"', '10"', '12"'];

export type CakeFlavor = 'vanilla' | 'chocolate' | 'redVelvet' | 'lemon' | 'earlGrey' | 'matcha';
export const CakeFlavors: CakeFlavor[] = ['vanilla','chocolate','redVelvet','lemon','earlGrey','matcha'];

export type Frosting = 'buttercream' | 'freshCream' | 'creamCheese' | 'ganache';
export const Frostings: Frosting[] = ['buttercream','freshCream','creamCheese','ganache'];

export type Decoration =
  | 'sprinkles'
  | 'fruit'
  | 'macaron'
  | 'chocolateShavings'
  | 'fondantFlowers'
  | 'customTopper';
export const Decorations: Decoration[] = [
  'sprinkles','fruit','macaron','chocolateShavings','fondantFlowers','customTopper'
];

export interface CakeTier {
  id: string;
  size: CakeSize;
  flavor: CakeFlavor;
  frosting: Frosting;
}

export interface CakeDesign {
  tiers: CakeTier[];
  decorations: Set<Decoration>;
  message: string;
  allergyNotes: string;
}

const baseBySize: Record<CakeSize, number> = {
  '6"': 238, '8"': 328, '10"': 438, '12"': 568,
};
const frostingAdd: Record<Frosting, number> = {
  buttercream: 0, freshCream: 20, creamCheese: 35, ganache: 40,
};
const flavorAdd: Record<CakeFlavor, number> = {
  vanilla: 0, chocolate: 18, redVelvet: 28, lemon: 12, earlGrey: 22, matcha: 30,
};
const decorationAdd: Record<Decoration, number> = {
  sprinkles: 18, fruit: 48, macaron: 58, chocolateShavings: 32, fondantFlowers: 78, customTopper: 98,
};

const servingsBySize: Record<CakeSize, number> = {
  '6"': 6, '8"': 10, '10"': 16, '12"': 24,
};

export function priceHKD(design: CakeDesign): number {
  const tiersTotal = design.tiers.reduce((acc, t) =>
    acc + baseBySize[t.size] + frostingAdd[t.frosting] + flavorAdd[t.flavor], 0);
  const decoTotal = Array.from(design.decorations).reduce((acc, d) => acc + decorationAdd[d], 0);
  const discount = design.tiers.length >= 2 ? 0.9 : 1;
  return Math.round((tiersTotal + decoTotal) * discount);
}

export function estimatedServings(design: CakeDesign): number {
  return design.tiers.reduce((acc, t) => acc + servingsBySize[t.size], 0);
}

export function newTierLike(last?: CakeTier): CakeTier {
  return {
    id: crypto.randomUUID(),
    size: last?.size ?? '8"',
    flavor: last?.flavor ?? 'vanilla',
    frosting: last?.frosting ?? 'buttercream',
  };
}

export function labelDecoration(d: Decoration): string {
  return d === 'customTopper' ? 'Custom Topper' : d.charAt(0).toUpperCase() + d.slice(1);
}